# LIVEFACE SYNC

A mobile-first browser PWA for local face tracking, stylized VFX/avatar rendering and WebRTC streaming.

## Modes
- **Local Preview**: camera → MediaPipe Face Landmarker (when CDN is reachable) → canvas VFX.
- **Host**: same pipeline, then `canvas.captureStream()` + optional microphone into WebRTC.
- **Viewer**: receives processed media from a peer; supports Fullscreen and browser/Android PiP where available.
- **One-Phone Split**: two `RTCPeerConnection` objects in one page for a real WebRTC loopback without a signaling server.

## Important
This project is intentionally a **stylized VFX/avatar** system. It is not designed for deception, secret impersonation, photorealistic identity replacement, or injecting a processed feed into WhatsApp/Zoom/Meet. Uploaded images should be owned/authorized/fictional. The UI labels output `VFX / SYNTHETIC`.

## Run on Termux
```bash
pkg update
pkg install nodejs git
cd liveface-sync
node --version
node tests/smoke.mjs
node server/server.js
```
The signaling server listens on `http://localhost:8787` by default. WebSocket URL is `ws://HOST:8787` (use `wss://` when deployed behind HTTPS).

For camera access on phones, serve the frontend over **HTTPS** (or localhost). GitHub Pages is suitable for the static frontend.

## GitHub Pages
Push the project to a repository, enable **Settings → Pages → GitHub Actions**, and the included workflow publishes the root directory. Because GitHub Pages cannot run the Node signaling server, set a separately hosted WebSocket URL in Host/Viewer. The app also works without a signaling server in One-Phone Split mode.

## Two-phone flow
1. Deploy frontend over HTTPS.
2. Deploy `server/` to a Node-capable host and expose its WebSocket URL.
3. Phone 1: Host → Start Camera → enter signaling URL → Create Session → Publish.
4. Phone 2: Viewer → enter same signaling URL + session code → Connect.
5. Use Viewer PiP if the browser/Android build supports it.

## Performance
The current engine requests 1280×720/30fps and draws to a canvas. For lower-end Android, change the constraints in `src/camera.js` and/or use the Low performance UI control when extending the engine. The recommended starting point for split-screen is 640×360 at 24–30fps.

## MediaPipe
`src/tracker.js` loads MediaPipe Tasks Vision and the Face Landmarker model from public CDNs at runtime. No paid AI API is required. If the CDN/model cannot load, the canvas still renders the selected stylized effect but the face status will remain untracked.
